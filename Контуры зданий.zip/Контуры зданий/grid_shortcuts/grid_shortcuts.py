from typing import List, Tuple, Union

import geopandas as gpd
import numpy as np
import shapely.ops
from geopandas import GeoSeries
from shapely.geometry import MultiPolygon, Polygon, LineString, Point, \
    MultiPoint, box, GeometryCollection
from shapely.geometry.base import BaseGeometry
from shapely.validation import make_valid

from boxkitten.image_products import ShapeProduct


class Orthogonalizer:

    def __init__(self,
                 shape_product: ShapeProduct,
                 tolerance=0.00001):
        self.product = shape_product
        self.tolerance = tolerance
        self.gdf = gpd.read_file(self.product.path)

    @property
    def geometry(self):
        return self.gdf.geometry

    def orthogonalize(self):
        simplified_geometry = self.gdf.geometry.simplify(
            tolerance=self.tolerance)
        self.gdf.geometry = self.cover(simplified_geometry)

    def cover(self, geometry: GeoSeries):
        for idx, shape in enumerate(geometry):
            if isinstance(shape, Polygon):
                points = self._find_farthest_points(shape)
                new_poly = self._collect_polygon_exterior(shape, points)
                if isinstance(new_poly, Polygon):
                    geometry[idx] = self._cover_polygon_with_boxes(new_poly)
                elif isinstance(new_poly, MultiPolygon):
                    geometry[idx] = MultiPolygon([
                        self._cover_polygon_with_boxes(poly) for poly in
                        new_poly.geoms
                    ])
            elif isinstance(shape, MultiPolygon):
                polygons = []
                for poly in shape.geoms:
                    points = self._find_farthest_points(poly)
                    new_poly = self._collect_polygon_exterior(poly, points)
                    polygons.append(self._cover_polygon_with_boxes(new_poly))
                geometry[idx] = MultiPolygon(polygons)
        return geometry

    def _cover_polygon_with_boxes(self, polygon: Union[Polygon, MultiPolygon]):
        for line in self.segments(polygon.exterior):
            polygon = polygon.union(box(*line.bounds))
        return polygon

    def _collect_polygon_exterior(self,
                                  polygon: Polygon,
                                  points: List[Point]
                                  ) -> Polygon:
        sorted_points = []
        for edge in self.segments(polygon.exterior):
            edge_points = [point for point in points if edge.distance(point)
                           < 1e-8]  #
            if edge_points:
                sorted_points.extend(edge_points)
        valid_polygon = make_valid(polygon)
        if isinstance(polygon, GeometryCollection):
            valid_polygon = MultiPolygon([poly for poly in polygon.geoms
                                          if isinstance(poly, Polygon)])
        return valid_polygon

    def _find_farthest_points(self, polygon: Polygon) -> List[Point]:
        grid = self._create_polygon_grid(polygon)
        # gpd.GeoDataFrame(geometry=GeoSeries(grid)).to_file(
        #     '/home/kalitka/Desktop/grid_shortcuts/grid/grid.shp')
        points = []
        for grid_part, intersection_poly in self._find_outer_intersections(
                polygon, grid):
            self._add_grid_intersections(grid_part,
                                         points,
                                         polygon)
            self._add_inland_points(grid_part, intersection_poly, points)
        return points

    def _add_grid_intersections(self, grid_part, points,
                                polygon):
        for edge in self.segments(grid_part.exterior):
            if edge.within(polygon):
                continue
            intersection = edge.intersection(polygon.exterior)
            if isinstance(intersection, Point):
                points.append(intersection)
            elif isinstance(intersection, MultiPoint):
                points.extend(intersection.geoms)
            elif isinstance(intersection, LineString) and \
                    intersection.is_empty:
                continue
            else:
                raise ValueError(f'Unknown intersection type: '
                                 f'{type(intersection)}')

    def _add_inland_points(self, grid_part: Polygon,
                           intersection_poly: Union[Polygon, MultiPolygon],
                           points: List):
        # TODO Проверять на наличие пересечений intersection_poly с сеткой
        # TODO Проверять длину пересечения с сеткой
        intersection_poly = shapely.ops.clip_by_rect(intersection_poly,
                                                     *grid_part.bounds)

        if isinstance(intersection_poly, Polygon):
            shared_paths = shapely.ops.shared_paths(
                grid_part.exterior,
                intersection_poly.exterior)[0].geoms
        elif isinstance(intersection_poly, MultiPolygon):
            shared_paths = []
            for poly in intersection_poly.geoms:
                shared_paths.extend(
                    shapely.ops.shared_paths(grid_part.exterior,
                                             poly.exterior)[0].geoms)
        else:
            raise TypeError('Polygon or Multipolygon geometry expected')

        clean_edges = []
        for edge in self.segments(grid_part.exterior):
            within_edge = [shared for shared in shared_paths
                           if not shared.within(edge)]
            if not any(within_edge):
                clean_edges.append(edge)
        if not clean_edges:
            return
        farthest_points = []
        for edge in clean_edges:
            if isinstance(intersection_poly, Polygon):
                farthest_points.append(
                    shapely.ops.nearest_points(edge,
                                               intersection_poly.exterior)[0]
                )
            elif isinstance(intersection_poly, MultiPolygon):
                farthest_points.extend(
                    shapely.ops.nearest_points(edge, poly.exterior)[0] for
                    poly in intersection_poly.geoms
                )
        points.extend(farthest_points)

    def _find_outer_intersections(self,
                                  polygon: Polygon,
                                  grid: MultiPolygon
                                  ) -> Tuple[Polygon, BaseGeometry]:
        outer_intersections = []
        grid_parts = []
        for grid_part in grid.geoms:
            is_inside = polygon.contains(grid_part)
            intersects = polygon.intersects(grid_part)
            if intersects and not is_inside:
                grid_parts.append(grid_part)
                outer_intersections.append(polygon.intersection(grid_part))
        # gpd.GeoDataFrame(geometry=GeoSeries(outer_intersections)).to_file(
        #     '/home/kalitka/Desktop/grid_shortcuts/intersections'
        #     '/outer_intersection.shp')
        # gpd.GeoDataFrame(geometry=GeoSeries(grid_parts)).to_file(
        #     '/home/kalitka/Desktop/grid_shortcuts/intersections/grid_parts'
        #     '.shp')

        return zip(grid_parts, outer_intersections)

    def _create_polygon_grid(self, polygon: Polygon) -> MultiPolygon:
        xmin, ymin, xmax, ymax = polygon.bounds
        length = abs(xmax - xmin) / 10
        width = abs(ymax - ymin) / 10
        cols = list(np.arange(xmin, xmax + width, width))
        rows = list(np.arange(ymin, ymax + length, length))

        polygons = []
        for x in cols[:-1]:
            for y in rows[:-1]:
                polygons.append(Polygon(
                    [(x, y), (x + width, y), (x + width, y + length),
                     (x, y + length)]))
        return MultiPolygon(polygons)

    @staticmethod
    def segments(curve):
        return list(
            map(LineString, zip(curve.coords[:-1], curve.coords[1:])))
