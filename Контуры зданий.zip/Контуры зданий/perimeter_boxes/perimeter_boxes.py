import geopandas as gpd
from geopandas import GeoSeries
from shapely.geometry import MultiPolygon, Polygon, LineString, Point
from shapely.ops import nearest_points

from boxkitten.image_products import ShapeProduct


class Orthogonalizer:

    def __init__(self,
                 shape_product: ShapeProduct,
                 tolerance=0.00001):
        self.product = shape_product
        self.tolerance = tolerance
        self.gdf = gpd.read_file(self.product.path)

    @property
    def geometry(self):
        return self.gdf.geometry

    def orthogonalize(self):
        simplified_geometry = self.gdf.geometry.simplify(
            tolerance=self.tolerance)
        self.gdf.geometry = self.cover(simplified_geometry)

    def cover(self, geometry: GeoSeries):
        for idx, shape in enumerate(geometry):
            if isinstance(shape, Polygon):
                boxed_polygon = self._cover_polygon_with_boxes(shape)
                geometry[idx] = self.find_closest_exterior(boxed_polygon,
                                                           shape)
            elif isinstance(shape, MultiPolygon):
                polygons = []
                for poly in shape:
                    boxed_polygon = self._cover_polygon_with_boxes(poly)
                    polygons.append(self.find_closest_exterior(
                        boxed_polygon, poly))

                geometry[idx] = MultiPolygon(polygons)
        return geometry

    def find_closest_exterior(self,
                              boxed_polygon: Polygon,
                              original_polygon: Polygon) -> Polygon:
        new_exterior = [nearest_points(original_polygon.exterior,
                                       Point(point))[0]
                        for line in self.segments(boxed_polygon.exterior)
                        for point in [*line.coords, line.centroid]]
        return Polygon(shell=new_exterior)

    def _cover_polygon_with_boxes(self, polygon: Polygon):
        for line in self.segments(polygon.exterior):
            polygon = polygon.union(line.bounds)
        return polygon

    @staticmethod
    def segments(curve):
        return list(
            map(LineString, zip(curve.coords[:-1], curve.coords[1:])))
