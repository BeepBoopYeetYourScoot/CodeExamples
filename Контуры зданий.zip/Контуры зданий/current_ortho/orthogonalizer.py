import math
import statistics

import geopandas as gpd
from geopandas import GeoDataFrame
from shapely import speedups
from shapely.geometry import Polygon, MultiPolygon

speedups.enable()


def _calculate_initial_compass_bearing(point_a, point_b):
    """
    Calculates the bearing between two points.
    The formulae used is the following:
        θ = atan2(sin(Δlong).cos(lat2),
                  cos(lat1).sin(lat2) − sin(lat1).cos(lat2).cos(Δlong))
    :Parameters:
      - `point_a: The tuple representing the latitude/longitude for the
        first point. Latitude and longitude must be in decimal degrees
      - `point_b: The tuple representing the latitude/longitude for the
        second point. Latitude and longitude must be in decimal degrees
    :Returns:
      The bearing in degrees
    :Returns Type:
      float
    """
    if (type(point_a) != tuple) or (type(point_b) != tuple):
        raise TypeError("Only tuples are supported as arguments")

    lat1 = math.radians(point_a[0])
    lat2 = math.radians(point_b[0])

    diff_long = math.radians(point_b[1] - point_a[1])

    x = math.sin(diff_long) * math.cos(lat2)
    y = (math.cos(lat1) * math.sin(lat2)
         - (math.sin(lat1) * math.cos(lat2) * math.cos(diff_long)))

    initial_bearing = math.atan2(x, y)

    # Now we have the initial bearing but math.atan2 return values
    # from -180° to + 180° which is not what we want for a compass bearing
    # The solution is to normalize the initial bearing as shown below
    initial_bearing = math.degrees(initial_bearing)
    compass_bearing = (initial_bearing + 360) % 360

    return compass_bearing


def _calculate_segment_angles(poly_simple: Polygon, max_angle_change=20):
    """
    Calculates angles of all polygon segments to cardinal directions.
    :Parameters:
      - `polySimple: shapely polygon object containing simplified building.
      - `maxAngleChange: angle (0,45> degrees. Sets the maximum angle deviation
                         from the cardinal direction for the segment to be still
                         considered to continue in the same direction as the
                         previous segment.
    :Returns:
      - original_angles: Segments bearing
      - correction_angles: Segments angles to the closest cardinal direction
      - direction_angles: Segments direction [N, E, S, W] as [0, 1, 2, 3]
    :Returns Type:
      list
    """
    # Convert limit angle to angle for subtraction
    max_angle_change = 45 - max_angle_change

    # Get points Lat/Lon
    simple_x = poly_simple.exterior.xy[0]
    simple_y = poly_simple.exterior.xy[1]

    # Calculate angle to cardinal directions for each segment of polygon
    original_angles = []  # Original angles
    correction_angles = []  # Correction angles used for rotation
    direction_angles = []  # 0,1,2,3 = N,E,S,W
    limit = [0] * 4

    for i in range(0, (len(simple_x) - 1)):
        point_1 = (simple_y[i], simple_x[i])
        point_2 = (simple_y[i + 1], simple_x[i + 1])
        angle = _calculate_initial_compass_bearing(point_1, point_2)

        if (45 + limit[1]) < angle <= (135 - limit[1]):
            original_angles.append(angle)
            correction_angles.append(angle - 90)
            direction_angles.append(1)

        elif (135 + limit[2]) < angle <= (225 - limit[2]):
            original_angles.append(angle)
            correction_angles.append(angle - 180)
            direction_angles.append(2)

        elif (225 + limit[3]) < angle <= (315 - limit[3]):
            original_angles.append(angle)
            correction_angles.append(angle - 270)
            direction_angles.append(3)

        elif (315 + limit[0]) < angle <= 360:
            original_angles.append(angle)
            correction_angles.append(angle - 360)
            direction_angles.append(0)

        elif 0 <= angle <= (45 - limit[0]):
            original_angles.append(angle)
            correction_angles.append(angle)
            direction_angles.append(0)

        limit = [0] * 4
        # Set angle limit for the current direction
        limit[direction_angles[i]] = max_angle_change
        # Extend the angles for the adjacent directions
        limit[(direction_angles[i] + 1) % 4] = -max_angle_change
        limit[(direction_angles[i] - 1) % 4] = -max_angle_change

    return original_angles, correction_angles, direction_angles


def _rotate_polygon(poly_simple: Polygon,
                    angle: float,
                    crs='epsg:4326') -> Polygon:
    """
    Rotates polygon around its centroid for given angle.
    :Parameters:
      - `poly_simple: shapely polygon object containing simplified building.
      - `angle: angle of rotation in decimal degrees.
                Positive = counter-clockwise, Negative = clockwise
    :Returns:
      - gdf_rotated: rotated polygon
    :Returns Type:
      shapely Polygon
    """
    return poly_simple


def _orthogonalize_polygon(polygon: Polygon,
                           max_angle_change=20,
                           skew_tolerance=40):
    """
    Master function that makes all angles in polygon outer and inner rings
    either 90 or 180 degrees.
    Idea adapted from JOSM function orthogonalize
    1) Calculate bearing [0-360 deg] of each polygon segment
    2) From bearing determine general direction [N, E, S ,W], then calculate
    angle deviation from the nearest cardinal direction for each segment
    3) Rotate polygon by median deviation angle to align segments with xy
    coord axes (cardinal directions)
    4) For vertical segments replace X coordinates of their points with mean
    value
       For horizontal segments replace Y coordinates of their points with
       mean value
    5) Rotate back
    :Parameters:
      - `polygon: shapely polygon object containing simplified building.
      - `maxAngleChange: angle (0,45> degrees. Sets the maximum angle deviation
                         from the cardinal direction for the segment to be still
                         considered to continue in the same direction as the
                         previous segment.
      - `skewTolerance: angle <0,45> degrees. Sets skew tolerance for segments
        that are at 45˚±Tolerance angle from the overall rectangular
        shape of the polygon. Useful when preserving e.g. bay windows on a
        house.
    :Returns:
      - orthogonalized_polygon: orthogonalized shapely polygon where all angles
      are 90 or 180 degrees
    :Returns Type:
      shapely Polygon
    """
    # Check if polygon has inner rings that we want to orthogonalize as well
    rings = [Polygon(polygon.exterior)]
    for inner in list(polygon.interiors):
        rings.append(Polygon(inner))

    orthogonalized_polygon = []
    for simplified_polygon in rings:

        # Get angles from cardinal directions of all segments
        (original_angles,
         correction_angles,
         direction_angles) = _calculate_segment_angles(simplified_polygon)

        # Calculate median angle that will be used for rotation
        if statistics.stdev(correction_angles) < 30:
            median_angle = statistics.median(correction_angles)
        else:
            median_angle = 45  # Account for cases when building is at ~45˚ and
            # we can't decide if to turn clockwise or anti-clockwise

        # Rotate polygon to align its edges to cardinal directions
        polySimpleR = _rotate_polygon(simplified_polygon, median_angle)

        # Get directions of rotated polygon segments
        (original_angles,
         correction_angles,
         direction_angles) = _calculate_segment_angles(polySimpleR,
                                                       max_angle_change)

        # Get Lat/Lon of rotated polygon points
        rotated_x = polySimpleR.exterior.xy[0].tolist()
        rotated_y = polySimpleR.exterior.xy[1].tolist()

        # Scan backwards to check if starting segment is a continuation of
        # straight region in the same direction
        shift = 0
        for i in range(1, len(direction_angles)):
            if direction_angles[0] == direction_angles[-i]:
                shift = i
            else:
                break
        # If the first segment is part of continuing straight region then
        # reset the index to its beginning
        if shift != 0:
            direction_angles = direction_angles[-shift:] + direction_angles[
                                                           :-shift]
            original_angles = original_angles[-shift:] + original_angles[
                                                         :-shift]
            rotated_x = rotated_x[-shift - 1:-1] + rotated_x[
                                                   :-shift]  # First and last
            # points are the same in closed polygons
            rotated_y = rotated_y[-shift - 1:-1] + rotated_y[:-shift]

        # Fix 180 degree turns (N->S, S->N, E->W, W->E)
        # Subtract two adjacent directions and if the difference is 2,
        # which means we have 180˚ turn (0,1,3 are OK) then use the direction
        # of the previous segment
        direction_angle_roll = direction_angles[1:] + direction_angles[0:1]
        direction_angles = [
            direction_angles[i - 1] if abs(
                direction_angles[i] - direction_angle_roll[i]) == 2 else
            direction_angles[i] for i in range(len(direction_angles))]

        # Cycle through all segments
        # Adjust points coordinates by taking the average of points in segment
        direction_angles.append(direction_angles[0])  # Append dummy value
        original_angles.append(original_angles[0])  # Append dummy value
        segment_buffer = []  # Buffer for determining which segments are part
        # of one large straight line

        for i in range(0, len(direction_angles) - 1):
            # Preserving skewed walls: Leave walls that are obviously meant
            # to be skewed 45˚+/- tolerance˚ (e.g.angle 30-60 degrees) off
            # main walls as untouched
            if (original_angles[i] % 90 > (45 - skew_tolerance)) and (
                    original_angles[i] % 90 < (45 + skew_tolerance)):
                continue

            # Dealing with adjacent segments following the same direction
            segment_buffer.append(i)
            # If next segment is of same orientation, we need
            # 180 deg angle for straight line. Keep checking.
            if direction_angles[i] == direction_angles[i + 1]:
                if (original_angles[i + 1] % 90 > (45 - skew_tolerance)) and (
                        original_angles[i + 1] % 90 < (45 + skew_tolerance)):
                    pass
                else:
                    continue

            if direction_angles[i] in {0,
                                       2}:  # for N,S segments avereage x
                # coordinate
                temp_x = statistics.mean(
                    rotated_x[segment_buffer[0]:segment_buffer[-1] + 2])
                # Update with new coordinates
                rotated_x[segment_buffer[
                              0]:segment_buffer[-1] + 2] = [temp_x] * (
                        len(segment_buffer) + 1)  # Segment has 2 points
                # therefore +1
            elif direction_angles[i] in {1,
                                         3}:  # for E,W segments avereage y
                # coordinate
                temp_y = statistics.mean(
                    rotated_y[segment_buffer[0]:segment_buffer[-1] + 2])
                # Update with new coordinates
                rotated_y[segment_buffer[
                              0]:segment_buffer[-1] + 2] = [temp_y] * (
                        len(segment_buffer) + 1)

            if 0 in segment_buffer:  # Copy change in first point to its last
                # point so we don't lose it during Reverse shift
                rotated_x[-1] = rotated_x[0]
                rotated_y[-1] = rotated_y[0]

            segment_buffer = []

        # Reverse shift, so we get polygon with the same start/end point as
        # before
        if shift != 0:
            rotated_x = rotated_x[shift:] + rotated_x[
                                            1:shift + 1]  # First and last
            # points are the same in closed polygons
            rotated_y = rotated_y[shift:] + rotated_y[1:shift + 1]
        else:
            rotated_x[0] = rotated_x[
                -1]  # Copy updated coordinates to first node
            rotated_y[0] = rotated_y[-1]

        # Create polygon from new points
        polyNew = Polygon(zip(rotated_x, rotated_y))

        polyNew = _rotate_polygon(polyNew, -median_angle)

        # Add to list of finihed rings
        orthogonalized_polygon.append(polyNew)

    # Recreate the original object
    orthogonalized_polygon = Polygon(orthogonalized_polygon[0].exterior,
                                     [inner.exterior for inner in
                                      orthogonalized_polygon[1:]])
    return orthogonalized_polygon


def orthogonalize_buildings(buildings: GeoDataFrame,
                            crs='epsg:4326') -> GeoDataFrame:
    buildings.crs = crs
    for i in range(0, len(buildings)):
        building = buildings.loc[i, 'geometry']

        if building.type == 'MultiPolygon':  # Multipolygons
            multipolygon = []

            for poly in building:
                orthogonalized_building = _orthogonalize_polygon(poly)
                multipolygon.append(orthogonalized_building)

            buildings.loc[i, 'geometry'] = gpd.GeoSeries(MultiPolygon(
                multipolygon)).values  # Workaround for Pandas/Geopandas bug
        else:  # Polygons
            orthogonalized_building = _orthogonalize_polygon(building)
            buildings.loc[i, 'geometry'] = orthogonalized_building
    return buildings
