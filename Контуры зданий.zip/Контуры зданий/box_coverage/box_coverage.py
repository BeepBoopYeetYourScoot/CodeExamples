from typing import Union

import geopandas as gpd
import numpy as np
from geopandas import GeoSeries
from shapely.geometry import MultiPolygon, Polygon, LineString, box, \
    GeometryCollection
from shapely.validation import make_valid

from boxkitten.image_products import ShapeProduct


class Orthogonalizer:

    def __init__(self,
                 shape_product: ShapeProduct,
                 tolerance=0.00001):
        self.product = shape_product
        self.tolerance = tolerance
        self.gdf = gpd.read_file(self.product.path)

    @property
    def geometry(self):
        return self.gdf.geometry

    def orthogonalize(self):
        simplified_geometry = self.gdf.geometry.simplify(
            tolerance=self.tolerance)
        self.gdf.geometry = self.cover(simplified_geometry)
        self.gdf.geometry = self.gdf.geometry.simplify(
            tolerance=self.tolerance)

    def cover(self, geometry: GeoSeries):
        for idx, shape in enumerate(geometry):
            if isinstance(shape, Polygon):
                if isinstance(shape, Polygon):
                    geometry[idx] = self._cover_polygon_with_boxes(shape)
                elif isinstance(shape, MultiPolygon):
                    geometry[idx] = MultiPolygon([
                        self._cover_polygon_with_boxes(poly) for poly in
                        shape.geoms
                    ])
            elif isinstance(shape, MultiPolygon):
                polygons = []
                for poly in shape.geoms:
                    polygons.append(self._cover_polygon_with_boxes(poly))
                geometry[idx] = MultiPolygon(polygons)
        return geometry

    def _cover_polygon_with_boxes(self, polygon: Union[Polygon, MultiPolygon]):
        grid = self._create_polygon_grid(polygon)
        outer_shapes = self._find_outer_intersections(polygon, grid)
        for poly in outer_shapes.geoms:
            polygon = polygon.union(box(*poly.bounds))
        return self._make_valid(polygon)

    @staticmethod
    def _make_valid(polygon: Polygon) -> Union[Polygon, MultiPolygon]:
        valid_polygon = make_valid(polygon)
        if isinstance(valid_polygon, (Polygon, MultiPolygon)):
            return valid_polygon
        if isinstance(valid_polygon, GeometryCollection):
            polygons = [poly for poly in valid_polygon.geoms if
                        isinstance(poly, Polygon)]
            multipolygons = [poly for poly in valid_polygon.geoms if
                             isinstance(poly, MultiPolygon)]
            for poly in multipolygons:
                polygons.extend(poly.geoms)
            return MultiPolygon(polygons)

    @staticmethod
    def _find_outer_intersections(polygon: Polygon,
                                  grid: MultiPolygon
                                  ) -> MultiPolygon:
        assert polygon.is_valid
        outer_intersections = []
        for grid_part in grid.geoms:
            is_inside = polygon.contains(grid_part)
            intersects = polygon.intersects(grid_part)
            if intersects and not is_inside:
                outer_intersections.append(polygon.intersection(grid_part))
        result_poly = []
        for poly in outer_intersections:
            if isinstance(poly, Polygon):
                result_poly.append(poly)
            elif isinstance(poly, MultiPolygon):
                result_poly.extend(poly.geoms)
        return MultiPolygon(result_poly)

    @staticmethod
    def _create_polygon_grid(polygon: Polygon) -> MultiPolygon:
        xmin, ymin, xmax, ymax = polygon.bounds
        length = abs(xmax - xmin) / 10
        width = abs(ymax - ymin) / 10
        cols = list(np.arange(xmin, xmax + width, width))
        rows = list(np.arange(ymin, ymax + length, length))

        polygons = []
        for x in cols[:-1]:
            for y in rows[:-1]:
                polygons.append(Polygon(
                    [(x, y), (x + width, y), (x + width, y + length),
                     (x, y + length)]))
        return MultiPolygon(polygons)

    @staticmethod
    def segments(curve):
        return list(
            map(LineString, zip(curve.coords[:-1], curve.coords[1:])))
