import os
from typing import Union, List, Tuple, Dict, Sequence

import geopandas as gpd
import numpy as np
from centerline.geometry import Centerline
from geopandas import GeoSeries
from scipy.spatial.qhull import QhullError
from shapely.geometry import MultiPolygon, LineString, MultiLineString, \
    Point
from shapely.geometry import Polygon
from shapely.geometry.base import GeometrySequence
from shapely.ops import split, cascaded_union, linemerge, nearest_points

from boxkitten.image_products import ShapeProduct

MAX_GRAPH_NODES = 1000

NEW_PATH = ('/home/kalitka/Desktop/full_result/new_orthogonalizer.shp')


class Orthogonalizer:

    def __init__(self,
                 shape_product: ShapeProduct,
                 tolerance=None):
        self.INTERPOLATION_DISTANCE = 0.0001
        self.product = shape_product
        self.tolerance = tolerance
        self.gdf = gpd.read_file(self.product.path)

        self._orthogonalize()
        self.save_product()

    @property
    def geometry(self) -> GeoSeries:
        return self.gdf.geometry

    def _orthogonalize(self):
        simplified_geometry = self.gdf.geometry.simplify(
            tolerance=self.tolerance)
        self.gdf.geometry = self._orthogonalize_geometry(simplified_geometry)

    def save_product(self,
                     path: Union[os.PathLike, str] = NEW_PATH):
        self.gdf.to_file(path)

    def _orthogonalize_geometry(self, geometry: GeoSeries) -> GeoSeries:
        for idx, shape in enumerate(geometry):
            if isinstance(shape, Polygon):
                geometry[idx] = self._orthogonalize_polygon(shape)
            elif isinstance(shape, MultiPolygon):
                geometry[idx] = MultiPolygon(
                    [self._orthogonalize_polygon(poly) for poly in shape])
        return geometry

    def _orthogonalize_polygon(self, polygon: Polygon) -> Polygon:
        try:
            voronoi_diagram = Centerline(
                polygon,
                interpolation_distance=self.INTERPOLATION_DISTANCE)
        except QhullError:
            return Polygon(polygon.bounds)
        centerline_graph = self.find_centerline_graph(voronoi_diagram)
        split_polygon = self.split_polygon_by_centerline(polygon,
                                                         centerline_graph)
        return self.collect_bounding_boxes(split_polygon)

    def split_polygon_by_centerline(self,
                                    polygon,
                                    graph,
                                    ) -> List[Polygon]:
        """
        Split polygons into small polygons by making
        orthogonal lines from centerline until the lines intersect
        with the border of the polygon
        """
        cutting_lines = []
        for edge in self.segments(graph):
            for point in edge.coords:
                point = Point(point)
                if polygon.exterior.contains(point):
                    continue

                nearest_point = nearest_points(polygon.exterior, point)[0]

                line = LineString([nearest_point, point])
                cutting_line = self.prolong_line_to_exterior(line, polygon)
                cutting_lines.append(cutting_line)

        merged_lines = linemerge([line for line in cutting_lines
                                  if not line.is_empty])

        if isinstance(merged_lines, LineString):
            return [poly for poly in split(polygon, merged_lines)]
        if isinstance(merged_lines, MultiLineString):
            split_polygons = [polygon]
            for line in merged_lines.geoms:
                new_polygons = []
                for poly in split_polygons:
                    new_polygons.extend(split(poly, line))
                split_polygons = [poly for poly in new_polygons if poly]
            return split_polygons
        raise ValueError('Unknown LineString type')

    @staticmethod
    def prolong_line_to_exterior(line: LineString,
                                 polygon: Polygon
                                 ) -> LineString:
        second_closest_point = polygon.exterior.interpolate(
            polygon.exterior.project(Point(line.coords[1])), normalized=True)

        return LineString([line.coords[0],
                           (second_closest_point.x, second_closest_point.y)])

    @staticmethod
    def collect_bounding_boxes(split_polygon: List[Polygon]) -> Polygon:
        boxes = []
        for poly in split_polygon:
            boxes.append(poly.minimum_rotated_rectangle)
        return cascaded_union(boxes)

    def find_centerline_graph(self,
                              voronoi_diagram: Centerline
                              ) -> LineString:
        first_point = np.array(voronoi_diagram.geoms[0].coords.xy).T
        graph = {tuple(first_point[0]): [tuple(first_point[1])]}
        geometries = voronoi_diagram.geoms

        self._assing_features_to_graph(geometries, graph)

        if len(graph) < MAX_GRAPH_NODES:
            return self._process_regular_graph(graph)
        else:
            return LineString()  # self._process_graph_with_excess_nodes(geometries,

    def _process_regular_graph(self,
                               graph: Dict[Tuple, List[Tuple]]
                               ) -> LineString:
        path = self._depth_first_search(graph, next(iter(graph)))
        centerline_coordinates_list: Sequence = []
        max_path_len = 0
        for p in path:
            if max_path_len < len(p):
                max_path_len = len(p)
                centerline_coordinates_list = p
        return LineString(coordinates=centerline_coordinates_list)

    @staticmethod
    def _process_graph_with_excess_nodes(geometries: GeometrySequence,
                                         graph: Dict[Tuple, List[Tuple]]):
        for _ in range(20):
            keys_to_remove = []
            for i in graph.keys():
                if len(graph[i]) <= 1:
                    keys_to_remove.append(i)
            for i in keys_to_remove:
                graph.pop(i, None)

            for i in graph.keys():
                points_to_keep = []
                for point in graph[i]:
                    if point not in keys_to_remove:
                        points_to_keep.append(point)
                graph[i] = points_to_keep
        for point_c in geometries:
            point_a, point_b = point_c.coords
            points_in_graph = (point_a in graph.keys()
                               and point_b in graph.keys())
            if points_in_graph:
                connection_exists = (point_b in graph[tuple(point_a)]
                                     and point_a in graph[tuple(point_b)])
                if connection_exists:
                    return LineString(coordinates=point_c.coords)

    @staticmethod
    def _assing_features_to_graph(geometries: GeometrySequence,
                                  graph: Dict[Tuple, List[Tuple]],
                                  ) -> None:
        for feature in geometries:
            start, end = np.array(feature.coords.xy).T
            start, end = tuple(start), tuple(end)
            if start in graph.keys():
                graph[start].append(end)
            else:
                graph[start] = [end]
            if end in graph.keys():
                graph[end].append(start)
            else:
                graph[end] = [start]

    def _depth_first_search(self,
                            graph: Dict[Tuple, List[Tuple]],
                            vertex,
                            seen=None,
                            path=None
                            ) -> List[Tuple]:
        seen = seen or []
        path = path or [vertex]

        seen.append(vertex)

        paths = []
        for t in graph[vertex]:
            if t not in seen:
                t_path = path + [t]
                paths.append(tuple(t_path))
                paths.extend(self._depth_first_search(graph, t, seen, t_path))
        return paths

    @staticmethod
    def segments(curve):
        return list(map(LineString, zip(curve.coords[:-1], curve.coords[1:])))
