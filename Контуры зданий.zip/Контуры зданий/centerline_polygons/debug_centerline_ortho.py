from boxkitten.image_postprocessors.orthogonalizer.centerline_ortho import \
    orthogonalize_polygons
from boxkitten.image_products import ShapeProduct

SHAPE_PATH = ('/home/kalitka/Desktop/test_oks_sq'
              '/test_oks_sq.shp')
shape_product = ShapeProduct(SHAPE_PATH)

path = orthogonalize_polygons(shape_product)


print(f'Finished orthogonalizing {path}')
